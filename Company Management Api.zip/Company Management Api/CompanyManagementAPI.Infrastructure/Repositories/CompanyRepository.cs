﻿using CompanyManagementAPI.Domain__.Entities;
using CompanyManagementAPI.Domain__.Interfaces;
using CompanyManagementAPI.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace CompanyManagementAPI.Infrastructure.Repositories;

public class CompanyRepository : ICompanyRepository
{
    private readonly AppDbContext _context;

    public CompanyRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<Company?> GetByIdAsync(int id)
        => await _context.Companies.FindAsync(id);

    public async Task<IEnumerable<Company>> GetAllAsync()
        => await _context.Companies.ToListAsync();


    public async Task AddAsync(Company company)
        => await _context.Companies.AddAsync(company);

    public void Update(Company company)
        => _context.Companies.Update(company);

    public void Remove(Company company)
        => _context.Companies.Remove(company);

    public async Task<bool> ExistsByCodeAsync(string companyCode)
        => await _context.Companies.AnyAsync(c => c.CompanyCode == companyCode);
}