﻿using CompanyManagementAPI.Domain__.Entities;
using Microsoft.EntityFrameworkCore;

namespace CompanyManagementAPI.Infrastructure.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<Company> Companies => Set<Company>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var entity = modelBuilder.Entity<Company>();

        // Soft Delete Filter
        entity.HasQueryFilter(c => c.Status == true);

        // Unique Code
        entity.HasIndex(c => c.CompanyCode)
              .IsUnique();

        // Parent-Child Relationship
        entity.HasOne(c => c.ParentCompany)
              .WithMany(p => p.ChildCompanies)
              .HasForeignKey(c => c.ParentCompanyId)
              .OnDelete(DeleteBehavior.Restrict);

        // Column Configurations
        entity.Property(c => c.CompanyName)
              .HasMaxLength(50)
              .IsRequired();

        entity.Property(c => c.CompanyCode)
              .HasMaxLength(6)
              .IsRequired();

        entity.Property(c => c.CompanyOfficeEmail)
              .HasMaxLength(50);

        entity.Property(c => c.CompanyPhone)
              .HasMaxLength(11);

        entity.Property(c => c.CompanyFaxNumber)
              .HasMaxLength(11);

        entity.Property(c => c.CompanyZip)
              .HasMaxLength(10);

        entity.Property(c => c.CompanyWebsite)
              .HasMaxLength(255);

        entity.Property(c => c.CompanyCalendarColor)
              .HasMaxLength(7);

        entity.Property(c => c.CompanyLogo)
              .HasColumnType("varbinary(max)");
    }
}