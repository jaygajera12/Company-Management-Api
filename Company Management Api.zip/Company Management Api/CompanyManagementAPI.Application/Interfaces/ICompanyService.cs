﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CompanyManagementAPI.Application.DTOs;



namespace CompanyManagementAPI.Application.Interfaces
{
    public interface ICompanyService
    {
        Task<CompanyResponseDto> CreateParentCompanyAsync(CompanyCreateDto dto);
        Task<CompanyResponseDto> GetParentByIdAsync(int id);
        Task DeleteParentAsync(int id);
        Task UpdateParentCompanyAsync(int id, CompanyUpdateDto dto);
    }
}
