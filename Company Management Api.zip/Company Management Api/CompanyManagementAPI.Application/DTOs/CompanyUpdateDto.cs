﻿namespace CompanyManagementAPI.Application.DTOs
{
    public class CompanyUpdateDto
    {
        public string CompanyName { get; set; } = null!;

        public string? CompanyOfficeEmail { get; set; }
        public string? CompanyPhone { get; set; }
        public string? CompanyFaxNumber { get; set; }
        public string? CompanyZip { get; set; }
        public string? CompanyWebsite { get; set; }
        public string? CompanyCalendarColor { get; set; }

        public byte[]? CompanyLogo { get; set; }
    }
}