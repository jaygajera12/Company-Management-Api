﻿namespace CompanyManagementAPI.Application.DTOs
{
    public class CompanyResponseDto
    {
        public int Id { get; set; }
        public string CompanyName { get; set; } = null!;
        public string CompanyCode { get; set; } = null!;
        public string? CompanyOfficeEmail { get; set; }
        public string? CompanyPhone { get; set; }
        public string? CompanyFaxNumber { get; set; }
        public string? CompanyZip { get; set; }
        public string? CompanyWebsite { get; set; }
        public string? CompanyCalendarColor { get; set; }
        public string? CompanyLogoBase64 { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public bool Status { get; set; }
    }
}