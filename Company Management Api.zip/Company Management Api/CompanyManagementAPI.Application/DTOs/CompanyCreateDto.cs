﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CompanyManagementAPI.Application.DTOs
{
    public class CompanyCreateDto
    {
        public string CompanyName { get; set; } = null!;
        public string CompanyOfficeEmail { get; set; } = null!;
        public string CompanyFaxNumber { get; set; } = null!;
        public string CompanyPhone { get; set; } = null!;
        public string CompanyZip { get; set; } = null!;
        public string CompanyWebsite { get; set; } = null!;
        public string CompanyCalendarColor { get; set; } = null!;
        public string? CompanyCode { get; set; } = null!;
        public byte[]? CompanyLogo { get; set; }       
        // ✅ byte[] use karo
    }
}
