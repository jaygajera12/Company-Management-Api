﻿using CompanyManagementAPI.Application.DTOs;
using CompanyManagementAPI.Application.Interfaces;
using CompanyManagementAPI.Domain__.Entities;
using CompanyManagementAPI.Domain__.Interfaces;

public class CompanyService : ICompanyService
{
    private readonly ICompanyRepository _repository;
    private readonly IUnitOfWork _unitOfWork;

    public CompanyService(
        ICompanyRepository repository,
        IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }
    public async Task<CompanyResponseDto> CreateParentCompanyAsync(CompanyCreateDto dto)
    {
        var companyCode = await GenerateUniqueCompanyCode(dto.CompanyCode);

        var company = new Company
        {
            CompanyName = dto.CompanyName.Trim(),
            CompanyCode = companyCode,
            CompanyOfficeEmail = dto.CompanyOfficeEmail,
            CompanyPhone = dto.CompanyPhone,
            CompanyFaxNumber = dto.CompanyFaxNumber,
            CompanyZip = dto.CompanyZip,
            CompanyWebsite = dto.CompanyWebsite,
            CompanyCalendarColor = dto.CompanyCalendarColor,
            CompanyLogo = dto.CompanyLogo,
            ParentCompanyId = null,
            CreatedAt = DateTime.UtcNow,
            Status = true
        };

        await _repository.AddAsync(company);
        await _unitOfWork.SaveChangesAsync();

        return new CompanyResponseDto
        {
            Id = company.Id,
            CompanyName = company.CompanyName,
            CompanyCode = company.CompanyCode,

            CompanyOfficeEmail = company.CompanyOfficeEmail,
            CompanyPhone = company.CompanyPhone,
            CompanyFaxNumber = company.CompanyFaxNumber,
            CompanyZip = company.CompanyZip,
            CompanyWebsite = company.CompanyWebsite,
            CompanyCalendarColor = company.CompanyCalendarColor,

            CompanyLogoBase64 = company.CompanyLogo != null
        ? Convert.ToBase64String(company.CompanyLogo)
        : null,

            CreatedAt = company.CreatedAt,
            UpdatedAt = company.UpdatedAt,
            Status = company.Status
        };
    }

    public async Task<CompanyResponseDto> GetParentByIdAsync(int id)
    {
        var company = await _repository.GetByIdAsync(id);

        if (company == null)
            throw new Exception("Company not found or already deleted.");

        if (company.ParentCompanyId != null)
            throw new Exception("Requested company is not a parent company.");

        return MapToResponse(company);
    }
    //public async Task UpdateParentCompanyAsync(int id, CompanyUpdateDto dto)
    //{
    //    var company = await _repository.GetByIdAsync(id);

    //    if (company == null)
    //        throw new Exception("Company not found.");

    //    if (company.ParentCompanyId != null)
    //        throw new Exception("Only parent companies can be updated here.");

    //    company.CompanyName = dto.CompanyName.Trim();
    //    company.CompanyOfficeEmail = dto.CompanyOfficeEmail;
    //    company.CompanyPhone = dto.CompanyPhone;
    //    company.CompanyFaxNumber = dto.CompanyFaxNumber;
    //    company.CompanyZip = dto.CompanyZip;
    //    company.CompanyWebsite = dto.CompanyWebsite;
    //    company.CompanyCalendarColor = dto.CompanyCalendarColor;

    //    if (dto.CompanyLogo != null)
    //        company.CompanyLogo = dto.CompanyLogo;

    //    company.UpdatedAt = DateTime.UtcNow;

    //    _repository.Update(company);
    //    await _unitOfWork.SaveChangesAsync();
    //}
    public async Task UpdateParentCompanyAsync(int id, CompanyUpdateDto dto)
    {
        var company = await _repository.GetByIdAsync(id);

        if (company == null || company.ParentCompanyId != null)
            throw new Exception("Parent company not found.");


        if (!string.IsNullOrWhiteSpace(dto.CompanyName))
            company.CompanyName = dto.CompanyName.Trim();

        if (dto.CompanyOfficeEmail != null)
            company.CompanyOfficeEmail = dto.CompanyOfficeEmail;

        if (dto.CompanyPhone != null)
            company.CompanyPhone = dto.CompanyPhone;

        if (dto.CompanyFaxNumber != null)
            company.CompanyFaxNumber = dto.CompanyFaxNumber;

        if (dto.CompanyZip != null)
            company.CompanyZip = dto.CompanyZip;

        if (dto.CompanyWebsite != null)
            company.CompanyWebsite = dto.CompanyWebsite;

        if (dto.CompanyCalendarColor != null)
            company.CompanyCalendarColor = dto.CompanyCalendarColor;

        if (dto.CompanyLogo != null)
            company.CompanyLogo = dto.CompanyLogo;

        company.UpdatedAt = DateTime.UtcNow;

        _repository.Update(company);
        await _unitOfWork.SaveChangesAsync();
    }
    // =============================
    // SOFT DELETE PARENT
    // =============================
    public async Task DeleteParentAsync(int id)
    {
        var company = await _repository.GetByIdAsync(id);

        if (company == null)
            throw new Exception("Company not found or already deleted.");

        if (company.ParentCompanyId != null)
            throw new Exception("Requested company is not a parent company.");

        if (!company.Status)
            return; 
        company.Status = false;
        company.UpdatedAt = DateTime.UtcNow;

        _repository.Update(company);
        await _unitOfWork.SaveChangesAsync();
    }

    // =============================
    // PRIVATE HELPERS
    // =============================

    private async Task<string> GenerateUniqueCompanyCode(string? providedCode)
    {
        if (!string.IsNullOrWhiteSpace(providedCode))
        {
            if (await _repository.ExistsByCodeAsync(providedCode))
                throw new Exception("Company code already exists.");

            return providedCode;
        }

        // Auto generate unique code
        string newCode;
        do
        {
            newCode = GenerateCompanyCode();
        }
        while (await _repository.ExistsByCodeAsync(newCode));

        return newCode;
    }

    private string GenerateCompanyCode()
    {
        var random = new Random();
        return new string(Enumerable
            .Repeat("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 6)
            .Select(s => s[random.Next(s.Length)])
            .ToArray());
    }

    private CompanyResponseDto MapToResponse(Company company)
    {
        return new CompanyResponseDto
        {
            Id = company.Id,
            CompanyName = company.CompanyName,
            CompanyCode = company.CompanyCode,

            CompanyOfficeEmail = company.CompanyOfficeEmail,
            CompanyPhone = company.CompanyPhone,
            CompanyFaxNumber = company.CompanyFaxNumber,
            CompanyZip = company.CompanyZip,
            CompanyWebsite = company.CompanyWebsite,
            CompanyCalendarColor = company.CompanyCalendarColor,

            CompanyLogoBase64 = company.CompanyLogo != null
                ? Convert.ToBase64String(company.CompanyLogo)
                : null,

          //  ParentCompanyId = company.ParentCompanyId,

            CreatedAt = company.CreatedAt,
            UpdatedAt = company.UpdatedAt,
            Status = company.Status
        };
    }
}