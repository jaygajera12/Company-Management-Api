﻿using CompanyManagementAPI.Application.DTOs;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyManagementAPI.Application.Validators
{
    public class CompanyCreateValidator : AbstractValidator<CompanyCreateDto>
    {
        public CompanyCreateValidator()
        {
            // Company Name
            RuleFor(x => x.CompanyName)
                .NotEmpty().WithMessage("Company name is required.")
                .MaximumLength(50)
                .Must(name => !string.IsNullOrWhiteSpace(name));

            // Company Code
            RuleFor(x => x.CompanyCode)
                .Length(6).When(x => !string.IsNullOrEmpty(x.CompanyCode))
                .WithMessage("Company code must be exactly 6 characters.")
                .Matches("^[a-zA-Z0-9]*$")
                .WithMessage("Company code must be alphanumeric.");

            // Email
            RuleFor(x => x.CompanyOfficeEmail)
                .EmailAddress()
                .MaximumLength(50)
                .When(x => !string.IsNullOrEmpty(x.CompanyOfficeEmail));

            // Phone / Fax (10-11 digits)
            RuleFor(x => x.CompanyPhone)
                .Matches(@"^\d{10,11}$")
                .When(x => !string.IsNullOrEmpty(x.CompanyPhone))
                .WithMessage("Phone must be 10-11 digits.");

            RuleFor(x => x.CompanyFaxNumber)
                .Matches(@"^\d{10,11}$")
                .When(x => !string.IsNullOrEmpty(x.CompanyFaxNumber))
                .WithMessage("Fax must be 10-11 digits.");

            // ZIP (US Format)
            RuleFor(x => x.CompanyZip)
                .Matches(@"^\d{5}(-\d{4})?$")
                .When(x => !string.IsNullOrEmpty(x.CompanyZip))
                .WithMessage("ZIP must be XXXXX or XXXXX-XXXX format.");

            // Website
            RuleFor(x => x.CompanyWebsite)
                .Must(BeValidUrl)
                .When(x => !string.IsNullOrEmpty(x.CompanyWebsite))
                .WithMessage("Website must start with http:// or https://")
                .MaximumLength(255);

            // Calendar Color (#RRGGBB)
            RuleFor(x => x.CompanyCalendarColor)
                .Matches("^#([A-Fa-f0-9]{6})$")
                .When(x => !string.IsNullOrEmpty(x.CompanyCalendarColor))
                .WithMessage("Calendar color must be valid hex format (#RRGGBB).");

            RuleFor(x => x.CompanyLogo)
                .Must(BeValidImage)
                .When(x => x.CompanyLogo != null)
                .WithMessage("Logo size must be less than 2MB.");
        }

        private bool BeValidImage(byte[]? logo)
        {
            if (logo == null)
                return true;

            // 2MB limit
            if (logo.Length > 2 * 1024 * 1024)
                return false;

            return true;
        }
        private bool BeValidUrl(string? url)
        {
            if (string.IsNullOrEmpty(url)) return true;

            return Uri.TryCreate(url, UriKind.Absolute, out var uriResult)
                && (uriResult.Scheme == Uri.UriSchemeHttp
                    || uriResult.Scheme == Uri.UriSchemeHttps);
        }
    }
}
