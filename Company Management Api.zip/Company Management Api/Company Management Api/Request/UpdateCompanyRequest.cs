﻿using Microsoft.AspNetCore.Http;

namespace Company_Management_Api.Requests
{
    public class UpdateCompanyRequest
    {
        public string CompanyName { get; set; } = null!;
        public string? CompanyOfficeEmail { get; set; }
        public string? CompanyPhone { get; set; }
        public string? CompanyFaxNumber { get; set; }
        public string? CompanyZip { get; set; }
        public string? CompanyWebsite { get; set; }
        public string? CompanyCalendarColor { get; set; }
        public IFormFile? Logo { get; set; }
    }
}