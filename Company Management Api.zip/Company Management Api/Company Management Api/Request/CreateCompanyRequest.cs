﻿using Microsoft.AspNetCore.Http;

namespace Company_Management_Api.Requests
{
    public class CreateCompanyRequest
    {
        public string CompanyName { get; set; } = null!;
        public string? CompanyCode { get; set; } = null!;
        public string CompanyOfficeEmail { get; set; } = null!;
        public string CompanyPhone { get; set; } = null!;
        public string CompanyFaxNumber { get; set; } = null!;
        public string CompanyZip { get; set; } = null!;
        public string CompanyWebsite { get; set; } = null!;
        public string CompanyCalendarColor { get; set; } = null!;

        public IFormFile? Logo { get; set; }
    }
}