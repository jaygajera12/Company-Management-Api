﻿using Company_Management_Api.Requests;
using CompanyManagementAPI.Application.DTOs;
using CompanyManagementAPI.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Company_Management_Api.Controllers
{
    [ApiController]
    [Route("api/v1/companies")]
    public class CompaniesController : ControllerBase
    {
        private readonly ICompanyService _service;

        public CompaniesController(ICompanyService service)
        {
            _service = service;
        }

        [HttpPost("parent")]
        public async Task<IActionResult> CreateParent([FromForm] CreateCompanyRequest request)
        {
            byte[]? logoBytes = null;

            if (request.Logo != null)
            {
                var allowedTypes = new[] { "image/jpeg", "image/png", "image/gif" };

                if (!allowedTypes.Contains(request.Logo.ContentType))
                    return BadRequest("Only JPEG, PNG or GIF allowed.");

                if (request.Logo.Length > 2 * 1024 * 1024)
                    return BadRequest("Logo must be less than 2MB.");

                using var memoryStream = new MemoryStream();
                await request.Logo.CopyToAsync(memoryStream);
                logoBytes = memoryStream.ToArray();
            }

            var dto = new CompanyCreateDto
            {
                CompanyName = request.CompanyName,
                CompanyCode = request.CompanyCode,
                CompanyOfficeEmail = request.CompanyOfficeEmail,
                CompanyPhone = request.CompanyPhone,
                CompanyFaxNumber = request.CompanyFaxNumber,
                CompanyZip = request.CompanyZip,
                CompanyWebsite = request.CompanyWebsite,
                CompanyCalendarColor = request.CompanyCalendarColor,
                CompanyLogo = logoBytes
            };

            var result = await _service.CreateParentCompanyAsync(dto);

            return CreatedAtAction(nameof(GetParentById), new { id = result.Id }, result);
        }

        [HttpGet("parent/{id}")]
        public async Task<IActionResult> GetParentById(int id)
        {
            var result = await _service.GetParentByIdAsync(id);
            return Ok(result);
        }
        [HttpPut("parent/{id}")]
        public async Task<IActionResult> UpdateParent( int id, [FromForm] UpdateCompanyRequest request)
        {
            byte[]? logoBytes = null;

            if (request.Logo != null)
            {
                var allowedTypes = new[] { "image/jpeg", "image/png", "image/gif" };

                if (!allowedTypes.Contains(request.Logo.ContentType))
                    return BadRequest("Only JPEG, PNG or GIF allowed.");

                if (request.Logo.Length > 2 * 1024 * 1024)
                    return BadRequest("Logo must be less than 2MB.");

                using var memoryStream = new MemoryStream();
                await request.Logo.CopyToAsync(memoryStream);
                logoBytes = memoryStream.ToArray();
            }

            var dto = new CompanyUpdateDto
            {
                CompanyName = request.CompanyName,
                CompanyOfficeEmail = request.CompanyOfficeEmail,
                CompanyPhone = request.CompanyPhone,
                CompanyFaxNumber = request.CompanyFaxNumber,
                CompanyZip = request.CompanyZip,
                CompanyWebsite = request.CompanyWebsite,
                CompanyCalendarColor = request.CompanyCalendarColor,
                CompanyLogo = logoBytes
            };

            await _service.UpdateParentCompanyAsync(id, dto);

            return NoContent();
        }



        [HttpDelete("parent/{id}")]
        public async Task<IActionResult> DeleteParent(int id)
        {
            await _service.DeleteParentAsync(id);
            return NoContent();
        }
    }
}