﻿using CompanyManagementAPI.Application.Interfaces;
using CompanyManagementAPI.Domain__.Interfaces;
using CompanyManagementAPI.Infrastructure.Data;
using CompanyManagementAPI.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using FluentValidation;
using FluentValidation.AspNetCore;
using CompanyManagementAPI.Application.Validators;


var builder = WebApplication.CreateBuilder(args);

    
builder.Services.AddControllers();

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new() { Title = "Company API", Version = "v1" });
});
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<CompanyCreateValidator>();
builder.Services.AddScoped<ICompanyRepository, CompanyRepository>();
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
builder.Services.AddScoped<ICompanyService, CompanyService>();

//////////////////////////////
// 🔹 BUILD APP
//////////////////////////////

var app = builder.Build();

//////////////////////////////
// 🔹 MIDDLEWARE
//////////////////////////////

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();