﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CompanyManagementAPI.Domain__.Common;

namespace CompanyManagementAPI.Domain__.Entities
{
    public class Company : BaseEntity
    {
        public string CompanyName { get; set; } = null!;
        public string CompanyCode { get; set; } = null!;

        // 🔥 New Profile Fields
        public string? CompanyOfficeEmail { get; set; }
        public string? CompanyPhone { get; set; }
        public string? CompanyFaxNumber { get; set; }
        public string? CompanyZip { get; set; }
        public string? CompanyWebsite { get; set; }
        public string? CompanyCalendarColor { get; set; }

        public byte[]? CompanyLogo { get; set; }

        // Parent-Child
        public int? ParentCompanyId { get; set; }
        public Company? ParentCompany { get; set; }
        public ICollection<Company> ChildCompanies { get; set; }
            = new List<Company>();
    }
}