﻿using CompanyManagementAPI.Domain__.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyManagementAPI.Domain__.Interfaces
{
    public interface ICompanyRepository
    {
        Task<Company?> GetByIdAsync(int id);
        Task<IEnumerable<Company>> GetAllAsync();
        Task AddAsync(Company company);
        void Update(Company company);
        void Remove(Company company);
        Task<bool> ExistsByCodeAsync(string companyCode);
    }
}
